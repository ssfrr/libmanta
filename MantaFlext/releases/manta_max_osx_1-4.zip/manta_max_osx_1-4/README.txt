Installation instructions:

Put manta.mxo in Cycling74/max-externals/
Put manta.maxhelp in Cycling74/max-help/
Put manta-objectmappings.txt in Cycling74/init/


